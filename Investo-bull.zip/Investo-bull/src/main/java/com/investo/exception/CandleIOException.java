package com.investo.exception;

public class CandleIOException extends RuntimeException{

	public CandleIOException() {
		super();
	}
	
	public CandleIOException(String message) {
		super(message);
	}
	
}
