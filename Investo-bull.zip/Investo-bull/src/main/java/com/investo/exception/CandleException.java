package com.investo.exception;

public class CandleException extends RuntimeException{

	public CandleException() {
		super();
	}
	
	public CandleException(String message) {
		super(message);
	}
	
}
